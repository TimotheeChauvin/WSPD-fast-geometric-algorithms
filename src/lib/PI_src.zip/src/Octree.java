
import Jcg.geometry.Point_3;
import Jcg.geometry.Vector_3;

/**
 * A class for representing an Octree
 * 
 * @author Luca Castelli Aleardi, Ecole Polytechnique
 * @version december 2018
 */
public class Octree {
	public OctreeNode root;
	
	public Octree(Point_3[] points){
		throw new Error("To be completed");
	}
	
}
